﻿using UnityEngine;
using UnityEngine.UI;

using System.Collections;
using System.Collections.Generic;

public class Game : MonoBehaviour {
	List<GameObject> grid;
	public GameObject monsterBase;
	public GameObject humanBase = null;
	public GameObject heartButton;
	public GameObject humanBaseSprite;
	public GameObject monsterBaseSprite;
	public int deadRetreived = 1;
	public int livingHumans = 100;
	public GameObject zombie;
	public GameObject spider;
	public GameObject slime;
	public int health = 100;
	public GameObject man1;
	public GameObject man2;
	public GameObject man3;
	public List<GameObject> directionalHexes;
	public GameObject monsterDestination;

	public List <GameObject> monsterList;
	public List <GameObject> humanList;
//	= GameObject.Find("Grid").GetComponent<HexSphereGrid> ().grid;
	// Use this for initialization
	void Start () {
		GameObject.Find ("Grid").GetComponent<HexSphereGrid> ().generateGrid ();
		grid = GameObject.Find ("Grid").GetComponent<HexSphereGrid> ().grid;


		int hexCount = 0;
		foreach (GameObject go in grid) {
			go.GetComponent<HexTile>().hexID = hexCount;
			hexCount++;
		}



		//setup teams

		//Evil(Player) base
		monsterBase = grid [0];
		monsterBase.GetComponent<HexTile> ().isBase = true;
		monsterBase.GetComponent<HexTile> ().isHuman = false;
		monsterBase.GetComponent<Renderer> ().material.color = Color.red;

		//human base
		humanBase = grid [grid.ToArray ().Length - 1];
		humanBase.GetComponent<HexTile> ().isBase = true;
		humanBase.GetComponent<HexTile> ().isHuman = true;
		humanBase.GetComponent<Renderer> ().material.color = Color.blue;

		//set sprites
		humanBase.GetComponent<HexTile> ().placeSpriteOnSurface (humanBaseSprite);
//		humanBase.GetComponent<HexTile> ().baseSprite.transform.localRotation = 290;

		monsterBase.GetComponent<HexTile> ().placeSpriteOnSurface (monsterBaseSprite);
//		monsterBase.GetComponent<HexTile> ().baseSprite.transform.localRotation.x = 290;


		//Make the possible monsters faded
		GameObject.Find ("Monster1").GetComponent<CanvasRenderer>().SetAlpha(0.25f);
		GameObject.Find ("Monster2").GetComponent<CanvasRenderer>().SetAlpha(0.25f);
		GameObject.Find ("Monster3").GetComponent<CanvasRenderer>().SetAlpha(0.25f);

		directionalHexes = GameObject.Find ("Grid").GetComponent<HexSphereGrid> ().nearbyHexes (monsterBase);

		monsterDestination = humanBase;

		InvokeRepeating ("spawnHuman", 0, 5);
//		Debug.Log (GameObject.Find ("Grid").GetComponent<HexSphereGrid> ().nearbyHexes (monsterBase));

	}
	
	// Update is called once per frame
	void Update () {
	


	}

	public void spawnMonser(int num){
		Debug.Log ("Spawning Monster #" + num);
		GameObject spawnedMonster = null;
		switch (num) {
		case 1:
			if (deadRetreived > 0){
				spawnedMonster = monsterBase.GetComponent<HexTile>().placeSpriteOnSurface(zombie);
				deadRetreived -= 1;
			}
			break;
		case 2:
			if (deadRetreived > 1){
				spawnedMonster = monsterBase.GetComponent<HexTile>().placeSpriteOnSurface(spider);
				deadRetreived -= 2;
			}
			break;
		case 3:
			if (deadRetreived > 2){
				spawnedMonster = monsterBase.GetComponent<HexTile>().placeSpriteOnSurface(slime);
				deadRetreived -= 3;
			}
			break;
		}

		spawnedMonster.GetComponent<MonsterMovement> ().currentHex = monsterBase;
		spawnedMonster.GetComponent<MonsterMovement> ().destination = monsterDestination;

		monsterList.Add (spawnedMonster);


	}

	public void spawnHuman(){
		Debug.Log ("Spawning Human");
		GameObject spawnedHuman = null;
		int num = Random.Range(1,3);
		Debug.Log (num);
		switch (num) {
		case 1:
			spawnedHuman = humanBase.GetComponent<HexTile>().placeSpriteOnSurface(man1);
			break;
		case 2:
			spawnedHuman = humanBase.GetComponent<HexTile>().placeSpriteOnSurface(man2);
			break;
		case 3:
			spawnedHuman = humanBase.GetComponent<HexTile>().placeSpriteOnSurface(man3);
			break;
		}
		spawnedHuman.GetComponent<HumanMovement> ().currentHex = humanBase;
		spawnedHuman.GetComponent<HumanMovement> ().destination = monsterBase;
		
		humanList.Add (spawnedHuman);
	}

	void FixedUpdate(){
		GameObject.Find ("DeadRetrieved").GetComponent<Text>().text = "Dead retrieved: " + deadRetreived;
		GameObject.Find ("LivingHumans").GetComponent<Text>().text = "Living Humans: " + livingHumans;
		GameObject.Find ("Health").GetComponent<Text> ().text = health.ToString();

		if (deadRetreived >= 1) {
			//GameObject.Find ("Monster1").GetComponent<Button>().enabled = true;
			GameObject.Find ("Monster1").GetComponent<CanvasRenderer>().SetAlpha(1f);
		}else {
			//GameObject.Find ("Monster1").GetComponent<Button>().enabled = false;
		}
		if (deadRetreived >= 2) {
			//GameObject.Find ("Monster2").GetComponent<Button>().enabled = true;
			GameObject.Find ("Monster2").GetComponent<CanvasRenderer> ().SetAlpha (1f);
		} else {
			//GameObject.Find ("Monster2").GetComponent<Button>().enabled = false;
		}
		if (deadRetreived >=3) {
			//GameObject.Find ("Monster3").GetComponent<Button>().enabled = true;
			GameObject.Find ("Monster3").GetComponent<CanvasRenderer>().SetAlpha(1f);
		}else {
			//GameObject.Find ("Monster3").GetComponent<Button>().enabled = false;
		}
	}

}
