﻿using UnityEngine;
using System.Collections;

public class Control : MonoBehaviour {
	public GameObject grid;
	public GameObject centerRotationPoint;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

//		grid.transform.RotateAround (centerRotationPoint.transform.position, Vector3.up, 20*Time.deltaTime);
		if (Input.GetButton ("Horizontal")) {
			if (Input.GetAxis("Horizontal") < 0){
				grid.transform.Rotate(
					-Vector3.forward * Time.smoothDeltaTime * 100
				);

			}
			if (Input.GetAxis("Horizontal") > 0){
				grid.transform.Rotate(
					Vector3.forward * Time.smoothDeltaTime * 100
				);
			}

		}
		if (Input.GetButton ("Vertical")) {
			if (Input.GetAxis("Vertical") < 0){
				grid.transform.Rotate(
					-Vector3.up * Time.smoothDeltaTime * 100
					);
				
			}
			if (Input.GetAxis("Vertical") > 0){
				grid.transform.Rotate(
					Vector3.up * Time.smoothDeltaTime * 100
					);
			}
			
		}

	}
}
