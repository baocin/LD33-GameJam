﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HexSphereGrid : MonoBehaviour {
	public GameObject prefab;
	public GameObject centerPoint;
	public int count = 10;
	public float size = 20;
	GameObject arrow;

	public List<GameObject> grid = new List<GameObject>();

	// Use this for initialization
	void Start () {
		//generateGrid ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	[ContextMenu("Create Points")]
	public void generateGrid(){
		List<Vector3> points = UniformPointsOnSphere (count, size);
		for(var i=0; i<count; i++) {
			GameObject g = Instantiate(prefab, transform.position+points[i], Quaternion.identity) as GameObject;
			g.transform.parent = transform;
			g.transform.LookAt(centerPoint.transform);
//			if (i == 0 || i == count-1){
//				g.transform.localPosition += g.transform.forward * 2f;
//				
//			}
//
//			if(i==0){
//				arrow = Instantiate(arrowPrefab, g.transform.position, g.transform.rotation) as GameObject;
//				arrow.transform.localPosition -= arrow.transform.forward * .5f;
//			}

//			LineRenderer lineRenderer = g.AddComponent<LineRenderer>();
//			lineRenderer.material = new Material(Shader.Find ("Particles/Additive"));
//			lineRenderer.SetColors(Color.white, Color.white);
//			lineRenderer.SetWidth(0.2f, 0.2f);
//			lineRenderer.SetVertexCount(20);


			grid.Add(g);
		}
	}

	List<Vector3> UniformPointsOnSphere(float N, float scale){
		List<Vector3> points = new List<Vector3> ();
		float i = Mathf.PI * (3 - Mathf.Sqrt (5));
		float o = 2 / N;
		for (int k = 0; k < N; k++) {
			var y = k * o - 1 + (o / 2);
			var r = Mathf.Sqrt(1 - y*y);
			var phi = k * i;
			points.Add(new Vector3(Mathf.Cos(phi)*r, y, Mathf.Sin(phi)*r) * scale);
		}
		return points;
	}

	public List<GameObject> nearbyHexes(GameObject hex){
		List<GameObject> hexes = new List<GameObject> ();
		Collider[] hitColliders = Physics.OverlapSphere(hex.transform.position, 1f);
		int j = 0;
		while (j < hitColliders.Length) {
//			Debug.Log (hitColliders[j].GetComponent<HexTile>().hexID);
			hexes.Add (hitColliders[j].gameObject);
			j++;
		}

		return hexes;
	}
	List<int> nearbyHexes(int hexID){
//		return nearbyHexes (hex.GetComponent<HexTile> ().hexID);

		return null;
	}

	GameObject getHexFromID(int id){
		foreach (GameObject go in grid) {
			if (go.GetComponent<HexTile>().hexID == id){
				return go;
			}
		}
		return null;
	}
}
