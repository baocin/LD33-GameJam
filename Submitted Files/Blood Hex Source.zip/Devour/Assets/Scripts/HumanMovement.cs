﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HumanMovement : MonoBehaviour {
	public GameObject currentHex;
	public GameObject destination;
	public List<GameObject> previousHexes;
	public float speed = 1;
	// Use this for initialization
	void Start () {
		InvokeRepeating ("Move", 5, speed);
	}
	
	// Update is called once per frame
	void Update () {
		if (currentHex == null) {
			Destroy(gameObject);
		}
	}
	
	GameObject FindMove(){
		
		List<GameObject> nearbyHexes = GameObject.Find ("Grid").GetComponent<HexSphereGrid> ().nearbyHexes (currentHex);
		nearbyHexes.Remove (currentHex);
		foreach (GameObject n in previousHexes) {
			nearbyHexes.Remove(n);
		}
		if (nearbyHexes.ToArray ().Length == 0) {
			currentHex.GetComponent<HexTile>().destroyTile();
		}
		GameObject furthestHex = nearbyHexes[0];
		float leastDistance = float.MaxValue;
		foreach (GameObject hex in nearbyHexes) {
			if (hex == null) continue;
			if (hex.GetComponent<HexTile>().pathable == false) continue;
			float currentDistance = Vector3.Distance(hex.transform.position, destination.transform.position);
			if (currentDistance < leastDistance){
				furthestHex = hex;
				leastDistance = currentDistance;
			}
			
		}
		return furthestHex;
		
		
		
	}
	
	void Move(){
		GameObject moveTo = FindMove ();
		if (moveTo == null)
			Destroy (gameObject);
		//		Debug.Log ("Moving from " + currentHex.GetComponent<HexTile> ().hexID + " to " + moveTo.GetComponent<HexTile> ().hexID);
		
		if (moveTo == destination) {
			Debug.Log ("Got to destination");
//			Camera.main.GetComponent<Game>().deadRetreived += 2;
			currentHex.GetComponent<HexTile> ().clearSprite ();
		}



		//intersected with something other than a base
		if (moveTo.GetComponent<HexTile> ().occupied && moveTo.GetComponent<HexTile> ().isBase == false) {
			Camera.main.GetComponent<Game>().deadRetreived += 1;

			moveTo.GetComponent<HexTile>().pathable = false;
			moveTo.GetComponent<HexTile>().clearSprite();
			moveTo.GetComponent<HexTile>().stain++;
			moveTo.GetComponent<HexTile>().updateColor();
		}
		currentHex.GetComponent<HexTile> ().occupied = false;
		moveTo.GetComponent<HexTile> ().placeGameObjectOnSurface (gameObject);

		moveTo.GetComponent<HexTile> ().occupied = true;
		//		currentHex.GetComponent<HexTile> ().clearSprite ();
		previousHexes.Add(currentHex);
		
		
		
		currentHex = moveTo;

		if (currentHex == destination) {
			Camera.main.GetComponent<Game>().health -= 20;
			if (Camera.main.GetComponent<Game>().health <= 0){
				currentHex.GetComponent<HexTile>().destroyTile();
				Application.LoadLevel ("YouLose");

//				StartCoroutine(LoadAfterDelay("SurveillanceModeSelectScreen"));

			}

		}
		
		
		
		
	}
	IEnumerator LoadAfterDelay(string levelName){
		Debug.Log ("Waiting....");
		yield return new WaitForSeconds(05); // wait 1 seconds
		Debug.Log ("Waiting....");

		
	}
}
