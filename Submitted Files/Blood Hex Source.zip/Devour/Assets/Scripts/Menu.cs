﻿using UnityEngine;
using System.Collections;

public class Menu : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void LoadGame(){
		Application.LoadLevel("Main");
	}

	public void Quit(){
		Application.Quit();
	}

	public void Instructions(){
		Application.LoadLevel ("Instructions");
	}

}
