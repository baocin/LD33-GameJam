﻿using UnityEngine;
using System.Collections;

public class MoveCamera : MonoBehaviour {
	public GameObject centerPoint;
	
	// Update is called once per frame
	void Update () {
		Camera.main.transform.LookAt (centerPoint.transform);

		if (Input.GetButton("Horizontal")){
			//Debug.Log (Input.GetAxis("Horizontal"));
			if (Input.GetAxis("Horizontal") < 0){
				Camera.main.transform.RotateAround (centerPoint.transform.position, Vector3.up, 100*Time.deltaTime);
//				Camera.main.transform.localPosition -= Camera.main.transform.right * Time.smoothDeltaTime * 10;
			}else if (Input.GetAxis("Horizontal") > 0){
				Camera.main.transform.RotateAround (centerPoint.transform.position, -Vector3.up, 100*Time.deltaTime);
//				Camera.main.transform.localPosition += Camera.main.transform.right * Time.smoothDeltaTime * 10;
			}
		}

		if (Input.GetButton("Vertical")){
			if (Input.GetAxis("Vertical") < 0){
				Camera.main.transform.RotateAround (centerPoint.transform.position, -Vector3.right, 100*Time.deltaTime);
				//				Camera.main.transform.localPosition -= Camera.main.transform.right * Time.smoothDeltaTime * 10;
			}else if (Input.GetAxis("Vertical") > 0){
				Camera.main.transform.RotateAround (centerPoint.transform.position, Vector3.right, 100*Time.deltaTime);
				//				Camera.main.transform.localPosition += Camera.main.transform.right * Time.smoothDeltaTime * 10;
			}
//			Camera.main.transform.localPosition += Camera.main.transform.up * Time.deltaTime * Input.GetAxis("Vertical") * 10;
		}

		if (Input.GetAxis ("Mouse ScrollWheel") != 0) {
			Debug.Log(Input.GetAxis("Mouse ScrollWheel"));
			//Camera.main.transform.localPosition += Camera.main.transform.forward * Time.deltaTime * Input.GetAxis ("Mouse ScrollWheel") * 10;
		}
		
		
	}
}